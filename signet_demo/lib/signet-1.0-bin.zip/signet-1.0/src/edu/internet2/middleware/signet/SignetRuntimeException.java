/*--
$Id: SignetRuntimeException.java,v 1.4 2006/02/09 10:24:59 lmcrae Exp $
$Date: 2006/02/09 10:24:59 $
 
Copyright 2006 Internet2, Stanford University

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/
package edu.internet2.middleware.signet;

/**
 * This exception is thrown whenever Signet encounters an error that cannot
 * be reasonably addressed by Signet application programs.
 * 
 */
public class SignetRuntimeException extends RuntimeException
{
  /**
   * 
   */
  public SignetRuntimeException()
  {
    super();
  }

  /**
   * @param message
   */
  public SignetRuntimeException(String message)
  {
    super(message);
  }

  /**
   * @param message
   * @param cause
   */
  public SignetRuntimeException(String message, Throwable cause)
  {
    super(message, cause);
  }

  /**
   * @param cause
   */
  public SignetRuntimeException(Throwable cause)
  {
    super(cause);
  }

}
