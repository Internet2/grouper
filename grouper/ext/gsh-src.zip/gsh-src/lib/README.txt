
# README

This file provides information on the third party libraries that ship
with *GrouperShell*.

$Id: README.txt 2 2007-05-11 18:13:14Z blair.christensen $

---

## bsh-2.0b4.jar

"Lightweight Scripting for Java"

* Version:  2.0b4 
* Source:   <http://beanshell.org/>
* License:  LGPL

