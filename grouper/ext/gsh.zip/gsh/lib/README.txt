
# README

This file provides information on the third party libraries that ship
with *GrouperShell*.

$Id: README.txt,v 1.1.1.1 2008/04/27 14:52:17 tzeller Exp $

---

## bsh-2.0b4.jar

"Lightweight Scripting for Java"

* Version:  2.0b4 
* Source:   <http://beanshell.org/>
* License:  LGPL

