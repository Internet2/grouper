Grouper client binary distribution:

- There is no build.xml, everything is built
- Here is information on grouperClient:

https://wiki.internet2.edu/confluence/display/GrouperWG/Grouper+Client

- Generally:

1. configure the non-example files: grouper.client.properties and grouper.client.usage.txt
2. make sure you have Java 1.6+ (same as Java 6+)
3. run and get the usage: java -jar grouperClient.jar
4. if you are running LDAP or WS, try one of those commands from usage
